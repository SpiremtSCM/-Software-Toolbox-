/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package xhabijks.pulse;

/**
 *
 * @author Administrator
 */
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.TooManyListenersException;

import javax.comm.CommPortIdentifier;
import javax.comm.PortInUseException;
import javax.comm.SerialPort;
import javax.comm.SerialPortEvent;
import javax.comm.SerialPortEventListener;
import javax.comm.UnsupportedCommOperationException;
import javax.swing.JOptionPane;

public class DserialPortMbus implements SerialPortEventListener
{
	public  CommPortIdentifier commPort;
	public static  String ybName = "【集成显卡】串口测试";
	private int outTime = 500;
	public SerialPort serial;
	private InputStream inputStream;
	private OutputStream outputStream;
	public byte[] ys = new byte[1024];
	public int count = 0;
	List<String> l = new ArrayList<String>();
	/**
	 * @方法名称：listPort
	 * @方法功能：列出所有可用的端口
	 * @返回值类型：void
	 */
	@SuppressWarnings("rawtypes")
	public void listPort() {
		CommPortIdentifier commPortId;
		Enumeration e = CommPortIdentifier.getPortIdentifiers();
		System.out.println("now to list all Port of this PC：" + e);

		while (e.hasMoreElements()) {
			commPortId = (CommPortIdentifier) e.nextElement();
			if (commPortId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
				//c.add(commPortId.getName());
				l.add(commPortId.getName());
				System.out.println(commPortId.getName() + ","
						+ commPortId.getCurrentOwner());
			}
		}
	}

	/**
	 * @方法名称：selectPort
	 * @方法功能：选择一个可用端口
	 * @返回值类型：void
	 */
	@SuppressWarnings("rawtypes")
	public void selectPort(Object com2) {
		CommPortIdentifier commPortId;
		this.commPort = null;
		Enumeration e = CommPortIdentifier.getPortIdentifiers();
		while (e.hasMoreElements()) {
			commPortId = (CommPortIdentifier) e.nextElement();
			if (commPortId.getPortType() == CommPortIdentifier.PORT_SERIAL
					&& commPortId.getName().equals(com2)) {
				this.commPort = commPortId;
				break;
			}
		}
	}

	/**
	 * @方法名称：checkPort
	 * @方法功能：检查端口是否正确连接
	 * @返回值类型：void
	 */
	public void checkPort() {
		if (commPort == null) {
			throw new RuntimeException("没有选择端口，请使用select()方法选择端口");
		}
		if (serial == null) {
			try {
				throw new RuntimeException("SerialPort对象无效");
			} catch (RuntimeException e1) {
			}
		}
	}

	/**
	 * @方法名称：openPort
	 * @方法功能：打开选择的串口
	 * @返回值：void
	 */
	public void openPort() {

		if (commPort == null) {
			System.out.println("该串口无效");
		} else {
			sp("选择端口成功，当前端口为：" + commPort.getName());
			try {
				serial = (SerialPort) commPort.open(ybName, outTime);
				read();
				sp("端口实例化成功：");
			} catch (PortInUseException e) {
				JOptionPane.showMessageDialog(null,
						"Serial occupied,Please use the other serial port",
						"Reprogramme", JOptionPane.PLAIN_MESSAGE, null);
			}
		}
	}

	/**
	 * @方法名称：write
	 * @方法功能：向串口写出数据
	 * @返回值：void
	 */
	public void write(byte[] ys2, int length) {
		checkPort();
		try {
			outputStream = new BufferedOutputStream(serial.getOutputStream());
		} catch (IOException e) {
			throw new RuntimeException("获取端口outputStream时出错" + e.getMessage());
		} catch (IllegalStateException e) {
		} catch (NullPointerException e) {
		}
		try {
			for (int i = 0; i < length; i++) {
				try {
					outputStream.write(ys2[i]);
				} catch (NullPointerException e) {
				}
			}
		} catch (IOException e) {
			throw new RuntimeException("向端口发送信息是出错" + e.getMessage());
		} finally {
			try {
				outputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
			}
		}

	}

	/**
	 * @方法名称：read
	 * @方法功能：读取数据
	 * @返回值：void
	 */
	public void read() {
		checkPort();
		try {
			inputStream = new BufferedInputStream(serial.getInputStream());
		} catch (IOException e) {
			throw new RuntimeException("获取端口inputStream出错" + e.getMessage());
		}
		try
		{
			serial.addEventListener(this);
		}
		catch (TooManyListenersException e)
		{
			throw new RuntimeException(e.getMessage());
		}
		serial.notifyOnDataAvailable(true);

	}

	/**
	 * @方法名称 :close
	 * @功能描述 :关闭 SerialPort
	 * @返回值类型 :void
	 */
	public void close() {
		try {
			serial.close();

		} catch (NullPointerException e) {
		}
	}

	public static void sp(String mes) {
		System.out.println(ybName + "---->" + mes);
	}

	public void serialEvent(SerialPortEvent arg0) {
		switch (arg0.getEventType()) {
		case SerialPortEvent.BI:/* Break interrupt,通讯中断 */
		case SerialPortEvent.OE:/* Overrun error，溢位错误 */
		case SerialPortEvent.FE:/* Framing error，传帧错误 */
		case SerialPortEvent.PE:/* Parity error，校验错误 */
		case SerialPortEvent.CD:/* Carrier detect，载波检测 */
		case SerialPortEvent.CTS:/* Clear to send，清除发送 */
		case SerialPortEvent.DSR:/* Data set ready，数据设备就绪 */
		case SerialPortEvent.RI:/* Ring indicator，响铃指示 */
		case SerialPortEvent.OUTPUT_BUFFER_EMPTY:/*
													 * Output buffer is
													 * empty，输出缓冲区清空
													 */
			break;
		case SerialPortEvent.DATA_AVAILABLE:/*
											 * Data available at the serial
											 * port，端口有可用数据。读到缓冲数组，输出到终端
											 */
			final byte[] readBuffer = new byte[1024];
			int a = 0;
			for (int i = 0; i < readBuffer.length; i++) {
				readBuffer[i] = (byte) 0x00;
			}
			try {
				while (inputStream.available() > 0) {
					try {
						Thread.sleep(500);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					inputStream.read(readBuffer);
					for (int i = 0; i < 1024; i++)
					{
						try 
						{
							if (readBuffer[i] == (byte) 0x00
									&& readBuffer[i + 1] == 0x00
									&& readBuffer[i + 2] == 0x00
									&& readBuffer[i + 3] == 0x00
									&& readBuffer[i + 4] == 0x00
									&& readBuffer[i + 5] == 0x00
									&& readBuffer[i + 6] == 0x00
									&& readBuffer[i + 7] == 0x00
									&& readBuffer[i + 8] == 0x00
									&& readBuffer[i + 9] == 0x00
									&& readBuffer[i + 10] == 0x00
									&& readBuffer[i + 11] == 0x00
									&& readBuffer[i + 12] == 0x00
									&& readBuffer[i + 13] == 0x00
									&& readBuffer[i + 14] == 0x00
									&& readBuffer[i + 15] == 0x00
									&& readBuffer[i + 16] == 0x00
									&& readBuffer[i + 17] == 0x00
									&& readBuffer[i + 18] == 0x00
									&& readBuffer[i + 19] == 0x00
									&& readBuffer[i + 20] == 0x00
									&& readBuffer[i + 21] == 0x00
									&& readBuffer[i + 22] == 0x00
									&& readBuffer[i + 23] == 0x00
									&& readBuffer[i + 24] == 0x00
									&& readBuffer[i + 25] == 0x00
									&& readBuffer[i + 26] == 0x00
									&& readBuffer[i + 27] == 0x00
									&& readBuffer[i + 28] == 0x00
									&& readBuffer[i + 29] == 0x00
									&& readBuffer[i + 30] == 0x00
									)
							{
								a = i;
								break;
							}
						}
						catch(ArrayIndexOutOfBoundsException e){}
					}
					for(int i = 0; i <= a; i++)
					{
						try
						{
							ys[count + i] = readBuffer[i];
						}
						catch (NullPointerException e){}
					}

					count = count + a;
				}
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}

		}

	}

	public void setBaud(int a)
	{
		try
		{
			serial.setSerialPortParams(a, SerialPort.DATABITS_8,
					SerialPort.STOPBITS_1, SerialPort.PARITY_EVEN);
		}
		catch (UnsupportedCommOperationException e)
		{
		}
		catch (IllegalStateException e)
		{
		} 
		catch (NullPointerException e)
		{
		}
	}

	/**
	 * @param args
	 */
}

